function info(){
    window.alert("This Music Player is designed by Group No. 11 ");
}
function devotional(){
    open("devotional.html");
}
function dance(){
    open("dance.html");
}
function romantic(){
    open("romantic.html");
}
function trending(){
    open("trending.html");
}
function byme(){
    open("bycreator.html");
}