function abc(){
    var songIndex = 0;
    var audio = new Audio('editsongs/e1.mp3');
    var playbtn = document.getElementById('masterPlay');
    var myProgressBar = document.getElementById('myprogressbar');
    var gif = document.getElementById('gif');
    var msname = document.getElementById('mastersongname');
    var songItems = Array.from(document.getElementsByClassName('songItem'));

    var songs=[
        {songName:"Night Changes", filePath:"editsongs/e1.mp3"},
        {songName:"Agar Tum Saath Ho", filePath:"editsongs/e2.mp3"},
        {songName:"Faded", filePath:"editsongs/e3.mp3"},
        {songName:"The Nights", filePath:"editsongs/e4.mp3"},
        {songName:"Believer", filePath:"editsongs/e5.mp3"},
        {songName:"Woh Din", filePath:"editsongs/e6.mp3"},
        {songName:"Thunder", filePath:"editsongs/e7.mp3"}
    ];

    playbtn.addEventListener('click', ()=>{
        //console.log("hi");
        if(audio.paused || audio.currentTime<=0){
            audio.play();
            playbtn.classList.remove('fa-play-circle');
            playbtn.classList.add('fa-pause-circle');
            gif.style.opacity = 1;
        }
        else{
            audio.pause();
            playbtn.classList.remove('fa-pause-circle');
            playbtn.classList.add('fa-play-circle');
            gif.style.opacity = 0;
        }
    })

    audio.addEventListener('timeupdate', ()=>{ 
        progress = parseInt((audio.currentTime/audio.duration)* 100); 
        myProgressBar.value = progress;
    })

    myProgressBar.addEventListener('change', ()=>{
        audio.currentTime = myProgressBar.value * audio.duration/100;
    })

    const makeAllPlays = ()=>{
        Array.from(document.getElementsByClassName('songItemPlay')).forEach((element)=>{
            element.classList.remove('fa-pause-circle');
            element.classList.add('fa-play-circle');
        })
    }

    Array.from(document.getElementsByClassName('songItemPlay')).forEach((element)=>{
        element.addEventListener('click', (e)=>{ 
            makeAllPlays();
            songIndex = parseInt(e.target.id);
            e.target.classList.remove('fa-play-circle');
            e.target.classList.add('fa-pause-circle');
            audio.src =`editsongs/e${songIndex+1}.mp3` ;
            msname.innerText = songs[songIndex].songName;
            audio.currentTime = 0;
            audio.play();
            gif.style.opacity = 1;
            playbtn.classList.remove('fa-play-circle');
            playbtn.classList.add('fa-pause-circle');
        })
    })

    document.getElementById('next').addEventListener('click', ()=>{
        if(songIndex>=6){
            songIndex = 0
        }
        else{
            songIndex += 1;
        }
        audio.src = `editsongs/e${songIndex+1}.mp3`;
        msname.innerText = songs[songIndex].songName;
        audio.currentTime = 0;
        audio.play();
        playbtn.classList.remove('fa-play-circle');
        playbtn.classList.add('fa-pause-circle');
        gif.style.opacity = 1;

    })

    document.getElementById('previous').addEventListener('click', ()=>{
        if(songIndex<=0){
            songIndex = 0
        }
        else{
            songIndex -= 1;
        }
        audio.src = `editsongs/e${songIndex+1}.mp3`;
        msname.innerText = songs[songIndex].songName;
        audio.currentTime = 0;
        audio.play();
        playbtn.classList.remove('fa-play-circle');
        playbtn.classList.add('fa-pause-circle');
        gif.style.opacity = 1;
    })
}