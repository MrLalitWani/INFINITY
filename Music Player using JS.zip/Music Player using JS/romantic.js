function abc(){
    var songIndex = 0;
    var audio = new Audio('romsongs/r1.mp3');
    var playbtn = document.getElementById('masterPlay');
    var myProgressBar = document.getElementById('myprogressbar');
    var gif = document.getElementById('gif');
    var msname = document.getElementById('mastersongname');
    var songItems = Array.from(document.getElementsByClassName('songItem'));

    var songs=[
        {songName:"Kesariya", filePath:"romsongs/r1.mp3"},
        {songName:"Raatan Lambiyaan", filePath:"romsongs/r2.mp3"},
        {songName:"Ranjha", filePath:"romsongs/r3.mp3"},
        {songName:"Tujhe Kitna Chahne Laga", filePath:"romsongs/r4.mp3"},
        {songName:"Ve Maahi", filePath:"romsongs/r5.mp3"},
        {songName:"Gerua", filePath:"romsongs/r6.mp3"},
        {songName:"Soch Na Sake", filePath:"romsongs/r7.mp3"}
    ];

    playbtn.addEventListener('click', ()=>{
        //console.log("hi");
        if(audio.paused || audio.currentTime<=0){
            audio.play();
            playbtn.classList.remove('fa-play-circle');
            playbtn.classList.add('fa-pause-circle');
            gif.style.opacity = 1;
        }
        else{
            audio.pause();
            playbtn.classList.remove('fa-pause-circle');
            playbtn.classList.add('fa-play-circle');
            gif.style.opacity = 0;
        }
    })

    audio.addEventListener('timeupdate', ()=>{ 
        progress = parseInt((audio.currentTime/audio.duration)* 100); 
        myProgressBar.value = progress;
    })

    myProgressBar.addEventListener('change', ()=>{
        audio.currentTime = myProgressBar.value * audio.duration/100;
    })

    const makeAllPlays = ()=>{
        Array.from(document.getElementsByClassName('songItemPlay')).forEach((element)=>{
            element.classList.remove('fa-pause-circle');
            element.classList.add('fa-play-circle');
        })
    }

    Array.from(document.getElementsByClassName('songItemPlay')).forEach((element)=>{
        element.addEventListener('click', (e)=>{ 
            makeAllPlays();
            songIndex = parseInt(e.target.id);
            e.target.classList.remove('fa-play-circle');
            e.target.classList.add('fa-pause-circle');
            audio.src =`romsongs/r${songIndex+1}.mp3` ;
            msname.innerText = songs[songIndex].songName;
            audio.currentTime = 0;
            audio.play();
            gif.style.opacity = 1;
            playbtn.classList.remove('fa-play-circle');
            playbtn.classList.add('fa-pause-circle');
        })
    })

    document.getElementById('next').addEventListener('click', ()=>{
        if(songIndex>=6){
            songIndex = 0
        }
        else{
            songIndex += 1;
        }
        audio.src = `romsongs/r${songIndex+1}.mp3`;
        msname.innerText = songs[songIndex].songName;
        audio.currentTime = 0;
        audio.play();
        playbtn.classList.remove('fa-play-circle');
        playbtn.classList.add('fa-pause-circle');
        gif.style.opacity = 1;

    })

    document.getElementById('previous').addEventListener('click', ()=>{
        if(songIndex<=0){
            songIndex = 0
        }
        else{
            songIndex -= 1;
        }
        audio.src = `romsongs/r${songIndex+1}.mp3`;
        msname.innerText = songs[songIndex].songName;
        audio.currentTime = 0;
        audio.play();
        playbtn.classList.remove('fa-play-circle');
        playbtn.classList.add('fa-pause-circle');
        gif.style.opacity = 1;
    })
}