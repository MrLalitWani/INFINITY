function abc(){
    var songIndex = 0;
    var audio = new Audio('dancesongs/da1.mp3');
    var playbtn = document.getElementById('masterPlay');
    var myProgressBar = document.getElementById('myprogressbar');
    var gif = document.getElementById('gif');
    var msname = document.getElementById('mastersongname');
    var songItems = Array.from(document.getElementsByClassName('songItem'));

    var songs=[
        {songName:"Zingaat", filePath:"dancesongs/da1.mp3"},
        {songName:"Pehli Nazar Main", filePath:"dancesongs/da2.mp3"},
        {songName:"Aankh Marey", filePath:"dancesongs/da3.mp3"},
        {songName:"Abhi To Party Shuru Hui Hain", filePath:"dancesongs/da4.mp3"},
        {songName:"Kamariya", filePath:"dancesongs/da5.mp3"},
        {songName:"Chogada Tara", filePath:"dancesongs/da6.mp3"},
        {songName:"Jugnu", filePath:"dancesongs/da7.mp3"}
    ];

    playbtn.addEventListener('click', ()=>{
        //console.log("hi");
        if(audio.paused || audio.currentTime<=0){
            audio.play();
            playbtn.classList.remove('fa-play-circle');
            playbtn.classList.add('fa-pause-circle');
            gif.style.opacity = 1;
        }
        else{
            audio.pause();
            playbtn.classList.remove('fa-pause-circle');
            playbtn.classList.add('fa-play-circle');
            gif.style.opacity = 0;
        }
    })

    audio.addEventListener('timeupdate', ()=>{ 
        progress = parseInt((audio.currentTime/audio.duration)* 100); 
        myProgressBar.value = progress;
    })

    myProgressBar.addEventListener('change', ()=>{
        audio.currentTime = myProgressBar.value * audio.duration/100;
    })

    const makeAllPlays = ()=>{
        Array.from(document.getElementsByClassName('songItemPlay')).forEach((element)=>{
            element.classList.remove('fa-pause-circle');
            element.classList.add('fa-play-circle');
        })
    }

    Array.from(document.getElementsByClassName('songItemPlay')).forEach((element)=>{
        element.addEventListener('click', (e)=>{ 
            makeAllPlays();
            songIndex = parseInt(e.target.id);
            e.target.classList.remove('fa-play-circle');
            e.target.classList.add('fa-pause-circle');
            audio.src =`dancesongs/da${songIndex+1}.mp3` ;
            msname.innerText = songs[songIndex].songName;
            audio.currentTime = 0;
            audio.play();
            gif.style.opacity = 1;
            playbtn.classList.remove('fa-play-circle');
            playbtn.classList.add('fa-pause-circle');
        })
    })

    document.getElementById('next').addEventListener('click', ()=>{
        if(songIndex>=6){
            songIndex = 0
        }
        else{
            songIndex += 1;
        }
        audio.src = `dancesongs/da${songIndex+1}.mp3`;
        msname.innerText = songs[songIndex].songName;
        audio.currentTime = 0;
        audio.play();
        playbtn.classList.remove('fa-play-circle');
        playbtn.classList.add('fa-pause-circle');
        gif.style.opacity = 1;
    })

    document.getElementById('previous').addEventListener('click', ()=>{
        if(songIndex<=0){
            songIndex = 0
        }
        else{
            songIndex -= 1;
        }
        audio.src = `dancesongs/da${songIndex+1}.mp3`;
        msname.innerText = songs[songIndex].songName;
        audio.currentTime = 0;
        audio.play();
        playbtn.classList.remove('fa-play-circle');
        playbtn.classList.add('fa-pause-circle');
        gif.style.opacity = 1;
    })
}