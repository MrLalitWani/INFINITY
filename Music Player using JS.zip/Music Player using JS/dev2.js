function abc(){
    var songIndex = 0;
    var audio = new Audio('devsongs/d1.mp3');
    var playbtn = document.getElementById('masterPlay');
    var myProgressBar = document.getElementById('myprogressbar');
    var gif = document.getElementById('gif');
    var msname = document.getElementById('mastersongname');
    var songItems = Array.from(document.getElementsByClassName('songItem'));
    var pa=document.getElementById('pause');

    var songs=[
        {songName:"Hanuman Chalisa", filePath:"devsongs/d1.mp3"},
        {songName:"Krishna Flute", filePath:"devsongs/d2.mp3"},
        {songName:"Deva Shree Ganesha", filePath:"devsongs/d3.mp3"},
        {songName:"Ganpati Aarti", filePath:"devsongs/d4.mp3"},
        {songName:"Gayatri Mantra", filePath:"devsongs/d5.mp3"},
        {songName:"Har Har Shambhu", filePath:"devsongs/d6.mp3"},
        {songName:"Morya Morya", filePath:"devsongs/d7.mp3"}
    ];
    pa.addEventListener('click',()=>{
        if(audio.pa)
        {
            playbtn=false;
        }
    })
    playbtn.addEventListener('click', ()=>{
        if(audio.paused || audio.currentTime<=0){
            audio.play();
            playbtn.classList.remove('fa-play-circle');
            playbtn.classList.add('fa-pause-circle');
            gif.style.opacity = 1;
        }
        else{
            audio.pause();
            playbtn.classList.remove('fa-pause-circle');
            playbtn.classList.add('fa-play-circle');
            gif.style.opacity = 0;
        }
    })

    audio.addEventListener('timeupdate', ()=>{ 
        progress = parseInt((audio.currentTime/audio.duration)* 100); 
        myProgressBar.value = progress;
    })

    myProgressBar.addEventListener('change', ()=>{
        audio.currentTime = myProgressBar.value * audio.duration/100;
    })

    const makeAllPlays = ()=>{
        Array.from(document.getElementsByClassName('songItemPlay')).forEach((element)=>{
            element.classList.remove('fa-pause-circle');
            element.classList.add('fa-play-circle');
        })
    }

    Array.from(document.getElementsByClassName('songItemPlay')).forEach((element)=>{
        element.addEventListener('click', (e)=>{ 
            makeAllPlays();
            songIndex = parseInt(e.target.id);
            e.target.classList.remove('fa-play-circle');
            e.target.classList.add('fa-pause-circle');
            audio.src = `devsongs/d${songIndex+1}.mp3`;
            msname.innerText = songs[songIndex].songName;
            audio.currentTime = 0;
            audio.play();
            gif.style.opacity = 1;
            playbtn.classList.remove('fa-play-circle');
            playbtn.classList.add('fa-pause-circle');
        })
    })

    document.getElementById('next').addEventListener('click', ()=>{
        if(songIndex>=6){
            songIndex = 0
        }
        else{
            songIndex += 1;
        }
        audio.src = `devsongs/d${songIndex+1}.mp3`;
        msname.innerText = songs[songIndex].songName;
        audio.currentTime = 0;
        audio.play();
        playbtn.classList.remove('fa-play-circle');
        playbtn.classList.add('fa-pause-circle');
        gif.style.opacity = 1;
    })

    document.getElementById('previous').addEventListener('click', ()=>{
        if(songIndex<=0){
            songIndex = 0
        }
        else{
            songIndex -= 1;
        }
        audio.src = `devsongs/d${songIndex+1}.mp3`;
        msname.innerText = songs[songIndex].songName;
        audio.currentTime = 0;
        audio.play();
        playbtn.classList.remove('fa-play-circle');
        playbtn.classList.add('fa-pause-circle');
        gif.style.opacity = 1;
    })
}